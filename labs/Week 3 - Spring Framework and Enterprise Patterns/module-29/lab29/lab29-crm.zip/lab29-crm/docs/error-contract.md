# Lab 29 — Error contract

| Case | Status | Notes |
| ---- | ------ | ----- |
| Validation | 400 | TODO: violations[] |
| Not found | 404 | CUS-9999 |
| Duplicate | 409 | CUS-1001 |
| Unexpected | 500 | no stack traces |


## Concepts to Discuss

1. **Main flow, validation vs domain exception:** a validation failure never reaches the controller body at all — Spring intercepts it as a `MethodArgumentNotValidException` before `create()` runs; a domain exception (not-found, duplicate, illegal transition) is thrown *from inside* the service after the request already passed shape validation.
2. **Trust boundary — DTO vs service vs database:** the DTO layer (`@Valid`) rejects malformed *shape* (blank fields, bad email format, wrong ID pattern); the service layer rejects invalid *business state* (duplicate ID, illegal transition) that no annotation could express; the database (not used for real persistence in this lab) would be the last line of defense for constraints like uniqueness under real concurrency.
3. **Success/failure contracts:** every error path returns the same `ErrorResponse` shape — `timestamp`, `status`, `error`, `message`, `path`, `correlationId`, `violations` — regardless of which handler produced it, which is the entire point of centralizing this in one `@RestControllerAdvice`.
4. **Stable identity in error payloads:** `CUS-1001` appearing in a 409's `message` field lets support immediately know which record collided, without needing to cross-reference anything else — the ID is as important in the failure path as it is in the success path.
5. **Retry implications:** 400/404/409 are never safe to blindly retry unchanged — the request itself is wrong or conflicts with existing state, and retrying identically just repeats the same failure. A 500/503 might be transient and worth one retry; 400/404/409 are not.
6. **Local shortcut vs production:** this lab's plain-English `message` strings are fine for a single-locale lab; production APIs serving multiple locales, or adopting `application/problem+json` (RFC 7807), would need a more formal, machine-parseable error-type field alongside the human-readable message.
7. **Evidence operators need:** `correlationId`, `timestamp`, and `path` together let an operator find the exact request in logs without needing the client to describe what they did — that's the whole reason all three ride along on every error body.
8. **Two app instances, one envelope:** because `GlobalExceptionHandler` has no instance state at all, every running instance produces byte-identical error shapes for the same failure — a client never sees a different error contract depending on which instance handled the request.
9. **Why forgetting `@Valid` is a production foot-gun:** the annotations on `CustomerRequest` do nothing at all without it — a bad email would silently reach `CustomerService.create()` and get persisted as-is, since nothing else in the code path re-checks shape. Failure Experiment 1 demonstrates exactly this.
10. **Lab 14/16 unification:** Lab 14's DTO constraint style and Lab 16's centralized exception-handler idea are now literally the same mechanism inside one Spring Boot app — `@Valid` + Bean Validation on the DTO, `@RestControllerAdvice` for the handler — rather than two separate patterns living in two separate labs.

## Lab 14/16 unify note (Step 9 requirement)

Lab 14 established that validation belongs on the request DTO, not buried in
undocumented service `if` checks — `CustomerRequest`'s `@NotBlank`/`@Email`/`@Pattern`
annotations here are that exact idea, just expressed with Jakarta Bean Validation
instead of hand-written checks. Lab 16 established that exception handling should be
centralized rather than scattered per-controller — `GlobalExceptionHandler` here is
that same idea, applied via Spring's `@RestControllerAdvice` instead of a manually
wired dispatcher. Neither pattern changed conceptually between the two labs and this
one; Boot just gave both patterns first-class framework support.

## SOAP / Spring-WS alignment note (Step 7 requirement)

The same `BusinessException` subtypes (`CustomerNotFoundException`,
`DuplicateCustomerException`, `InvalidStatusTransitionException`) that map to REST
status codes here should map to SOAP faults the same way Lab 24's
`SoapFaultMappingExceptionResolver` did — `CustomerNotFoundException` to a CLIENT fault
with a not-found reason, exactly as before. The goal is one set of domain exception
types with two thin protocol-specific mapping layers (this `GlobalExceptionHandler` for
REST, Lab 24's fault resolver for SOAP), not two independently-invented error
vocabularies that could drift apart. Implementing the SOAP side isn't required here —
just documenting that REST and SOAP should never disagree about what a given business
failure means.
